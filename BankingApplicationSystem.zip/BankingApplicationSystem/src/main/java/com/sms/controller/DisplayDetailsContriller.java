package com.sms.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.sms.model.Details;
import com.sms.model.User;
import com.sms.service.UserService;

@Controller
public class DisplayDetailsContriller {
	@Autowired
	public UserService userService;

	@RequestMapping(value = "/EnterAcc", method = RequestMethod.GET)
	public ModelAndView showRegister(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView("EnterAcc");
		mav.addObject("detail", new Details());
		return mav;
	}

	@RequestMapping(value = "/detailsProcess", method = RequestMethod.POST)
	public ModelAndView addUser(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("details") Details details) {
		ModelAndView mav = new ModelAndView("AccountDetails");
		Details det = userService.DisplayDetails(details);

		mav.addObject("accountNumber", det.getAccountNumber());
		mav.addObject("balance", det.getBalance());
		mav.addObject("type", det.getType());
		mav.addObject("interest", det.getInterest());
		mav.addObject("username", det.getUsername());
		return mav;
	}
}

// @RequestMapping(value = "/detailsProcess", method = RequestMethod.GET)
// public ModelAndView addUser(HttpServletRequest request, HttpServletResponse
// response)
// {
// ModelAndView mav = new ModelAndView("AccountDetails");
//
// Details det= userService.DisplayDetails(details);
// mav.addObject("detail", new Details());
// mav.addObject("accountNumber",det.getAccountNumber());
// mav.addObject("balance",det.getBalance());
// mav.addObject("type",det.getType());
// mav.addObject("interest",det.getInterest());
// return mav;
// }
