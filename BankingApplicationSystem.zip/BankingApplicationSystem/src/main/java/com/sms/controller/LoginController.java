package com.sms.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.sms.model.Details;
import com.sms.model.Login;
import com.sms.model.User;
import com.sms.service.UserService;

@Controller
public class LoginController {
	@Autowired
	UserService userService;

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView showLogin(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView("login");
		mav.addObject("login", new Login());
		ModelAndView mav2 = new ModelAndView("AccountDetails");
		mav.addObject("detail", new Details());

		return mav;
	}

	@RequestMapping(value = "/loginProcess", method = RequestMethod.POST)
	public ModelAndView loginProcess(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("login") Login login) {
		ModelAndView mav = null;
		User user = userService.validateUser(login);
		if (null != user) {
			// mav = new ModelAndView("welcome");
			// mav.addObject("firstname", user.getFirstname());
			//
			//
			//
			// User user1 = userService.validateUser(login);
			mav = new ModelAndView("EnterAccountNumber");

		} else {
			mav = new ModelAndView("login");
			mav.addObject("message", "Username or Password is wrong!!");
		}
		return mav;
	}
	//// void RequestMapping(value = "/loginProcess", method =
	//// RequestMethod.POST)
	// public ModelAndView loginProcess(HttpServletRequest request,
	//// HttpServletResponse response,
	// @ModelAttribute("details") Details details) {
	// ModelAndView mav = null;
	// Details user1 = userService.DisplayDetails(details);
	// if (null != user1) {
	// mav = new ModelAndView("AccountDetails");
	// mav.addObject("accountNumber", user1.getAccountNumber());
	//
	//
	//// @ModelAttribute("details")Details details1){
	//// Details user11 = userService.DisplayDetails(details1);
	//// mav = new ModelAndView("AccountDetails");
	////
	//// mav.addObject("firstname", user11.ge());
	//// mav.addObject("username", user11.getUsername());
	////
	//
	//
	//
	// } else {
	// mav = new ModelAndView("login");
	// mav.addObject("message", "Username or Password is wrong!!!!");
	// }
	// return mav;
	// }
	//

}