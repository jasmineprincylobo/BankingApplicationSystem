package com.sms.service;

import com.sms.model.*;

public interface UserService {
	void register(User user);

	void delete(Login login);

	User validateUser(Login login);

	Details DisplayDetails(Details details);
}
