package com.sms.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.sms.dao.UserDao;
import com.sms.model.Details;
import com.sms.model.Login;
import com.sms.model.User;

public class UserServiceImpl implements UserService {
	@Autowired
	UserDao userDao;

	public void register(User user) {
		userDao.register(user);
	}

	public void delete(Login login) {
		userDao.delete(login);
	}

	public User validateUser(Login login) {
		return userDao.validateUser(login);
	}

	public Details DisplayDetails(Details details) {
		return userDao.DisplayDetails(details);
	}

}
