package com.sms.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.sms.model.Details;
import com.sms.model.Login;
import com.sms.model.User;

public class UserDaoImpl implements UserDao {
	@Autowired
	DataSource datasource;
	@Autowired
	JdbcTemplate jdbcTemplate;

	public void register(User user) {
		String sql = "insert into customer values(?,?,?,?,?,?,?)";
		jdbcTemplate.update(sql, new Object[] { user.getUsername(), user.getPassword(), user.getFirstname(),
				user.getLastname(), user.getEmail(), user.getAddress(), user.getPhone() });
	}

	public User validateUser(Login login) {
		String sql = "select * from customer where username='" + login.getUsername() + "' and password='"
				+ login.getPassword() + "'";
		List<User> users = jdbcTemplate.query(sql, new UserMapper());
		return users.size() > 0 ? users.get(0) : null;
	}

	public Details DisplayDetails(Details details) {
		String sql1 = "select * from customerDetails where accountNumber='" + details.getAccountNumber() + "'";
		List<Details> details1 = jdbcTemplate.query(sql1, new DetailsMapper());
		return details1.size() > 0 ? details1.get(0) : null;

	}

	public void delete(Login login) {

		String sql = "delete from customer where username='" + login.getUsername() + "'";

	}

}

class UserMapper implements RowMapper<User> {
	public User mapRow(ResultSet rs, int arg1) throws SQLException {
		User user = new User();
		user.setUsername(rs.getString("username"));
		user.setPassword(rs.getString("password"));
		user.setFirstname(rs.getString("firstname"));
		user.setLastname(rs.getString("lastname"));
		user.setEmail(rs.getString("email"));
		user.setAddress(rs.getString("address"));
		user.setPhone(rs.getString("phone"));
		return user;
	}

}

class DetailsMapper implements RowMapper<Details> {
	public Details mapRow(ResultSet rs, int arg1) throws SQLException {
		Details detail = new Details();
		detail.setAccountNumber(rs.getString("accountNumber"));
		detail.setUsername(rs.getString("username"));
		detail.setBalance(rs.getString("balance"));
		detail.setType(rs.getString("type"));
		detail.setInterest(rs.getString("interest"));

		return detail;
	}
}
