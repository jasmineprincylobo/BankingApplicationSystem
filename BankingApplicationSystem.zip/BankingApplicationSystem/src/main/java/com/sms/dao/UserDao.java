package com.sms.dao;

import com.sms.model.Details;
import com.sms.model.Login;
import com.sms.model.User;

public interface UserDao {
	void register(User user);

	User validateUser(Login login);

	Details DisplayDetails(Details details);

	void delete(Login login);
}